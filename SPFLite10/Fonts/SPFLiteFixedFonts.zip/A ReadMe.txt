This ZIP file contains a variety of fixed pitch fonts which may be used with
SPFLite.

All files here may be used freely; there is a CopyWrite file for each font
noting its source, please honor any additional restrictions which may be
included.

The current list of included fonts is:

AnonymousRegular
DejaVu Sans Mono
DejaVu Sans Mono Bold
IBM3270
MS LineDraw
PixelCarnage Monospace
ProggyClean
ProggySmall
ProggySquare
QuickType Mono
Raize
Raster/Raster15
Raster12
Raster13
Raster14
RasterTTF (Compatible with Raster/Raster14 but scalable, better for printing)
Triskweline

To install any of these Fonts:

1. Open Control Panel

2. Open Fonts

3. Select File -> Install New Font

4. Use the selection box to move to the directory where you un-zipped the font
   package and select the desired font.

5. Use the SPFLite OPTIONS command, select the Screen Tab and use the normal
   Font selection to choose the newly installed font.


